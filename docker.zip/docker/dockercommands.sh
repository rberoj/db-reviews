sudo docker login --username AWS --password $(/usr/local/bin/aws ecr get-login-password --region us-east-1 ) 588515432336.dkr.ecr.us-east-1.amazonaws.com
sudo docker build . -t 588515432336.dkr.ecr.us-east-1.amazonaws.com/elcdemo-demo
sudo docker push 588515432336.dkr.ecr.us-east-1.amazonaws.com/elcdemo-demo
aws ecs stop-task --cluster "demo-CacheDemoECSService" --task  $(aws ecs list-tasks --cluster "demo-CacheDemoECSService" --service "demo" --output text --query taskArns[0]) 