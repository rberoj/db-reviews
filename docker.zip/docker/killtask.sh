aws ecs stop-task --cluster "demo-CacheDemoECSService" --task arn:aws:ecs:us-east-1:588515432336:task/demo-CacheDemoECSService/2c567523a3a04c678e05b41199445120
